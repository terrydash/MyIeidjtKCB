﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IeidjtuKCB.Model
{
    public class ReplaceTagModel
    {
        public string TagName { get; set; }
        public string TagValue { get; set; }
    }
}
